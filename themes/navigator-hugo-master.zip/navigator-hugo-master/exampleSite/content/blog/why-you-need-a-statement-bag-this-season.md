---
title: Why You Need a Statement Bag
date: 2018-07-08T12:11:29+06:00
image: images/blog/post-2.jpg
author: Arya Stark
---
### A cleansing hot shower or bath

I like to start with taking a shower or a bath when getting ready for bed. I’ll always incorporate either Himalayan pink salt or Epsom salt into my routine. Then, I’ll do an in-shower meditation, just releasing my day and allowing it to wash down the drain. I like to start from the neck down to symbolize washing and removing anything, and then I go from the feet up after to symbolize recharging my energy.

### Setting the mood with incense

A lot of the times before bed I’ll pick a lavender or moon scent. I really like the scents from the brand HEM. Other times, if I’m needing to cleanse my space before bed, I like to use Frankincense & Myrrh incense because it’s really good at helping you feel sleepy time vibes. I have horrible insomnia so I’m somebody who really has to set my mood before going to bed.

